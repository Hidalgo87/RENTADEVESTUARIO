import sys
from mundo.tienda import Tienda


class Consola:

    def __init__(self):
        self.tienda = Tienda()
        self.opciones = {
            "1": self.registrar_usuario,
            "2": self.mostrar_prendas,
            "3": self.alquilar_prenda,
            "4": self.mostrar_planes,
            "5": self.mostrar_prendas_clima,
            "6": self.mostrar_top,
            "7": self.comprar_ropa,
            "8": self.salir
        }

    def mostar_menu(self):
        print("""
        \n
        BIENVENIDO A RENTUARIO
        |||||||||||||||||||||||||||||||||||
        Menú de opciones:\n
        1. Registrar usuario
        2. Mostrar las prendas
        3. Alquilar prenda
        4. Mostrar planes personalizados
        5. Mostrar prendas según el clima
        6. Mostrar top 3 de prendas más alquiladas
        7. Comprar la ropa 
        8. Salir
        |||||||||||||||||||||||||||||||||||
        """)

    def ejecutar(self):
        while True:
            self.mostar_menu()
            opcion = input("Seleccione una opción: ")
            accion = self.opciones.get(opcion)
            if accion is not None:
                accion()
            else:
                print(f"ERROR: {opcion} no es una opción válida")

    def registrar_usuario(self):
        print("INFO: AÚN NO ESTÁ IMPLEMENTADO")

    def mostrar_prendas(self):
        print("\n- CODIGO -- PRENDAS -- CLIMA -- P.Alquiler -- P.Compra")
        for prenda in self.tienda.prendas:
            print(prenda)

    def alquilar_prenda(self):
        print("- ALQUILAR PRENDA")
        cedula = int(input("Ingrese su cédula: "))
        codigo = int(input("Ingrese el codigo de la prenda: "))
        tiempo = int(input("Ingrese por tiempo que desea alquilarla: "))
        resp = self.tienda.alquilar_prenda(cedula, codigo, tiempo)
        if resp:
            print("INFO: Ahora la prenda está reservada")
        else:
            print("ERROR: La prenda no está disponible")

    def mostrar_planes(self):
        print("INFO: AÚN NO ESTÁ IMPLEMENTADO")

    def mostrar_prendas_clima(self):
        print("- PRENDAS SEGUN EL CLIMA")
        clima = input("Ingrese el clima que desee: \n  VERANO, INVIERNO O TODOS: ")
        prendas_climas = self.tienda.mostrar_prendas(clima)
        for prendas in prendas_climas:
            print(f"{prendas}")

    def mostrar_top(self):
        print("INFO: AÚN NO ESTÁ IMPLEMENTADO")

    def comprar_ropa(self):
        print("INFO: AÚN NO ESTÁ IMPLEMENTADO")

    def salir(self):
        print("\nMUCHAS GRACIAS POR USAR LA APLICACIÓN")
        sys.exit(0)
