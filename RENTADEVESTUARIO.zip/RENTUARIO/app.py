from ui.consola import Consola


if __name__ == "__main__":
    consola = Consola()
    consola.ejecutar()
