"""
Registrar ropa
Alquilar ropa
Mostrar un grupo de prendas relacionadas con el clima
"""


class Prenda:

    def __init__(self, codigo: int, nombre: str, clima: str,
                 valor_prenda: int, valor_alquiler: int):
        self.codigo = codigo
        self.nombre = nombre
        self.disponibilidad_renta = True
        self.clima = clima
        self.valor_prenda = valor_prenda
        self.valor_alquiler = valor_alquiler
        self.rentas_mes = 0

    def __str__(self) -> str:
        return f"{self.codigo} - {self.nombre} - {self.clima} - {self.valor_alquiler} - {self.valor_prenda}"

    def esta_disponible(self) -> bool:
        if self.disponibilidad_renta:
            self.disponibilidad_renta = False
            return True
        else:
            return False


class Renta:

    def __init__(self, prenda: Prenda, tiempo: int, entregar_prenda: bool, estado: bool):
        self.tiempo = tiempo
        self.prenda = prenda
        self.entregar_prenda = entregar_prenda
        self.estado = estado


class Usuario:

    def __init__(self, cedula: int, correo: str, numero_rentas: int = 0, deuda: int = 0):
        self.cedula = cedula
        self.correo = correo
        self.numero_rentas = numero_rentas
        self.deuda = deuda
        self.orden: dict[int:Renta] = {}

    def __str__(self):
        return f"cedula: {self.cedula}"

    def crear_orden(self, prenda: Prenda, tiempo: int) -> dict[int: Renta]:
        alquiler = Renta(prenda, tiempo, entregar_prenda=False, estado=True)
        self.orden[self.cedula] = alquiler
        self.numero_rentas += 1
        self.deuda += prenda.valor_alquiler * tiempo

    def comprobar_planes(self, cedula: int) -> bool:
        pass


class Tienda:

    def __init__(self):
        self.prendas: list[Prenda] = []
        self.usuarios: list[Usuario] = []
        self.registrar_ropa()

    def registrar_ropa(self) -> list[Prenda]:
        p1 = Prenda(1, "Buso", "INVIERNO", 40000, 100)
        p2 = Prenda(2, "Pantaloneta", "VERANO", 10000, 40)
        p3 = Prenda(3, "Corbata", "TODOS", 20000, 120)
        p4 = Prenda(4, "Sandalias", "VERANO", 15000, 65)
        p5 = Prenda(5, "Sombrero", "VERANO", 35000, 96)
        p6 = Prenda(6, "Botas", "INVIERNO", 50000, 114)
        p7 = Prenda(7, "Guantes", "INVIERNO", 4000, 20)
        p8 = Prenda(8, "Tenis", "TODOS", 120000, 354)
        self.prendas.append(p1)
        self.prendas.append(p2)
        self.prendas.append(p3)
        self.prendas.append(p4)
        self.prendas.append(p5)
        self.prendas.append(p6)
        self.prendas.append(p7)
        self.prendas.append(p8)
        u1 = Usuario(1, "juanma@gmail.com")
        u2 = Usuario(2, "matius@gmail.com")
        u3 = Usuario(3, "juanfer@gmail.com")
        u4 = Usuario(4, "luisacardona@gmail.com")
        u5 = Usuario(5, "jesusalvira20@gmail.com")
        self.usuarios.append(u1)
        self.usuarios.append(u2)
        self.usuarios.append(u3)
        self.usuarios.append(u4)
        self.usuarios.append(u5)
        return self.prendas

    def buscar_prenda(self, codigo: int):
        for prenda in self.prendas:
            if prenda.codigo == codigo:
                return prenda

    def mostrar_prendas(self, clima: str) -> list[Prenda]:
        ropa = []
        for prenda in self.prendas:
            if prenda.clima == clima:
                ropa.append(prenda)
        return ropa

    def buscar_usuario(self, cedula: int):
        for usuario in self.usuarios:
            if usuario.cedula == cedula:
                return usuario
        return None

    def alquilar_prenda(self, cedula: int, codigo: int, tiempo: int) -> bool:
        """El tiempo es en días"""
        prenda = self.buscar_prenda(codigo)
        if prenda.esta_disponible():
            usuario = self.buscar_usuario(cedula)
            usuario.crear_orden(prenda, tiempo)
            return True
        else:
            return False
